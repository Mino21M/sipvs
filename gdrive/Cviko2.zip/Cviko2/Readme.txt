

Certificate 
	- obsahuje certifikat (podpisovatel.cer) a privatny kluc (podpisovatel.pfx)
	- dalej su tam info o certifikate certifikacnej autority + linka na CRL

DSigClient
	- www.slovensko.sk
	- dokumentacia pre integratorov https://www.slovensko.sk/sk/na-stiahnutie/informacie-pre-integratorov-ap
	- testXmlAtl.htm je priklad pouzitia komponentu na podpisovanie v HTML stranke
	- online testovacia stranka na testovanie

FormatPodpisu
	- obsahuje dokumenty definujuce format podpisu ako ho vytvara D.Signer XAdES
	- zaroven su tu linky a dokumenty na XML Signature + XAdES specifikaciu
	- odporucam si to precitat v nasledovnom poradi (aby ste orientacne mali predstavu o pojmoch a strukture)
		1. xmlsignature
		2. xades (zamerat sa na EPES a XadesT format)
		3. profil xades zep + format datovych objektov (zamerat sa na EPES + xadesT)


Sample
	- ukazka pouzitia podpisovana pre formular danoveho priznania
	- ukazka pouzitia DBrigdeJS

