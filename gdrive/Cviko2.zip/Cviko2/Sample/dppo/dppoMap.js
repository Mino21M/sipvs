var inputy=new Array();
var inputyMena=new Array();
var inputyId=new Array();
var inputyUpperCase=new Array();
var inputyTypy=new Array();

inputy.push('0_0_0_0');
inputyMena['0_0_0_0']='rdp';
inputyId['rdp']='0_0_0_0';
inputyTypy['0_0_0_0']='checkbox';
inputyUpperCase['0_0_0_0']='1';

inputy.push('0_0_0_1');
inputyMena['0_0_0_1']='odp';
inputyId['odp']='0_0_0_1';
inputyTypy['0_0_0_1']='checkbox';
inputyUpperCase['0_0_0_1']='1';

inputy.push('0_0_0_2');
inputyMena['0_0_0_2']='ddp';
inputyId['ddp']='0_0_0_2';
inputyTypy['0_0_0_2']='checkbox';
inputyUpperCase['0_0_0_2']='1';

inputy.push('0_0_3');
inputyMena['0_0_3']='dic';
inputyId['dic']='0_0_3';
inputyTypy['0_0_3']='cislo';
inputyUpperCase['0_0_3']='1';

inputy.push('0_0_4');
inputyMena['0_0_4']='ico';
inputyId['ico']='0_0_4';
inputyTypy['0_0_4']='cislo';
inputyUpperCase['0_0_4']='1';

inputy.push('0_0_5');
inputyMena['0_0_5']='pravna_forma';
inputyId['pravna_forma']='0_0_5';
inputyTypy['0_0_5']='cislo';
inputyUpperCase['0_0_5']='1';

inputy.push('0_0_6');
inputyMena['0_0_6']='obch_meno';
inputyId['obch_meno']='0_0_6';
inputyTypy['0_0_6']='cislo';
inputyUpperCase['0_0_6']='0';

inputy.push('0_0_7_0');
inputyMena['0_0_7_0']='ulica';
inputyId['ulica']='0_0_7_0';
inputyTypy['0_0_7_0']='cislo';
inputyUpperCase['0_0_7_0']='1';

inputy.push('0_0_7_1');
inputyMena['0_0_7_1']='cislo';
inputyId['cislo']='0_0_7_1';
inputyTypy['0_0_7_1']='cislo';
inputyUpperCase['0_0_7_1']='1';

inputy.push('0_0_7_2');
inputyMena['0_0_7_2']='psc';
inputyId['psc']='0_0_7_2';
inputyTypy['0_0_7_2']='cislo';
inputyUpperCase['0_0_7_2']='1';

inputy.push('0_0_7_3');
inputyMena['0_0_7_3']='obec';
inputyId['obec']='0_0_7_3';
inputyTypy['0_0_7_3']='cislo';
inputyUpperCase['0_0_7_3']='1';

inputy.push('0_0_7_4');
inputyMena['0_0_7_4']='stat';
inputyId['stat']='0_0_7_4';
inputyTypy['0_0_7_4']='cislo';
inputyUpperCase['0_0_7_4']='1';

inputy.push('0_0_7_5');
inputyMena['0_0_7_5']='tel_predvolba';
inputyId['tel_predvolba']='0_0_7_5';
inputyTypy['0_0_7_5']='cislo';
inputyUpperCase['0_0_7_5']='1';

inputy.push('0_0_7_6');
inputyMena['0_0_7_6']='tel_cislo';
inputyId['tel_cislo']='0_0_7_6';
inputyTypy['0_0_7_6']='cislo';
inputyUpperCase['0_0_7_6']='1';

inputy.push('0_0_7_7');
inputyMena['0_0_7_7']='fax_predvolba';
inputyId['fax_predvolba']='0_0_7_7';
inputyTypy['0_0_7_7']='cislo';
inputyUpperCase['0_0_7_7']='1';

inputy.push('0_0_7_8');
inputyMena['0_0_7_8']='fax_cislo';
inputyId['fax_cislo']='0_0_7_8';
inputyTypy['0_0_7_8']='cislo';
inputyUpperCase['0_0_7_8']='1';

inputy.push('0_0_7_9_0');
inputyMena['0_0_7_9_0']='nazov_banky_1';
inputyId['nazov_banky_1']='0_0_7_9_0';
inputyTypy['0_0_7_9_0']='cislo';
inputyUpperCase['0_0_7_9_0']='1';

inputy.push('0_0_7_9_1');
inputyMena['0_0_7_9_1']='ucet_1';
inputyId['ucet_1']='0_0_7_9_1';
inputyTypy['0_0_7_9_1']='cislo';
inputyUpperCase['0_0_7_9_1']='1';

inputy.push('0_0_7_9_2');
inputyMena['0_0_7_9_2']='kod_banky_1';
inputyId['kod_banky_1']='0_0_7_9_2';
inputyTypy['0_0_7_9_2']='cislo';
inputyUpperCase['0_0_7_9_2']='1';

inputy.push('0_0_7_10_0');
inputyMena['0_0_7_10_0']='nazov_banky_2';
inputyId['nazov_banky_2']='0_0_7_10_0';
inputyTypy['0_0_7_10_0']='cislo';
inputyUpperCase['0_0_7_10_0']='1';

inputy.push('0_0_7_10_1');
inputyMena['0_0_7_10_1']='ucet_2';
inputyId['ucet_2']='0_0_7_10_1';
inputyTypy['0_0_7_10_1']='cislo';
inputyUpperCase['0_0_7_10_1']='1';

inputy.push('0_0_7_10_2');
inputyMena['0_0_7_10_2']='kod_banky_2';
inputyId['kod_banky_2']='0_0_7_10_2';
inputyTypy['0_0_7_10_2']='cislo';
inputyUpperCase['0_0_7_10_2']='1';

inputy.push('0_0_8_0');
inputyMena['0_0_8_0']='konatel_priezvisko';
inputyId['konatel_priezvisko']='0_0_8_0';
inputyTypy['0_0_8_0']='cislo';
inputyUpperCase['0_0_8_0']='1';

inputy.push('0_0_8_1');
inputyMena['0_0_8_1']='konatel_meno';
inputyId['konatel_meno']='0_0_8_1';
inputyTypy['0_0_8_1']='cislo';
inputyUpperCase['0_0_8_1']='1';

inputy.push('0_0_8_2');
inputyMena['0_0_8_2']='konatel_titul';
inputyId['konatel_titul']='0_0_8_2';
inputyTypy['0_0_8_2']='cislo';
inputyUpperCase['0_0_8_2']='1';

inputy.push('0_0_8_3');
inputyMena['0_0_8_3']='konatel_postavenie';
inputyId['konatel_postavenie']='0_0_8_3';
inputyTypy['0_0_8_3']='cislo';
inputyUpperCase['0_0_8_3']='1';

inputy.push('0_0_8_4_0');
inputyMena['0_0_8_4_0']='konatel_ulica_cislo';
inputyId['konatel_ulicacislo']='0_0_8_4_0';
inputyTypy['0_0_8_4_0']='cislo';
inputyUpperCase['0_0_8_4_0']='1';

inputy.push('0_0_8_4_1');
inputyMena['0_0_8_4_1']='konatel_psc';
inputyId['konatel_psc']='0_0_8_4_1';
inputyTypy['0_0_8_4_1']='cislo';
inputyUpperCase['0_0_8_4_1']='1';

inputy.push('0_0_8_4_2');
inputyMena['0_0_8_4_2']='konatel_obec';
inputyId['konatel_obec']='0_0_8_4_2';
inputyTypy['0_0_8_4_2']='cislo';
inputyUpperCase['0_0_8_4_2']='1';

inputy.push('0_0_8_4_3');
inputyMena['0_0_8_4_3']='konatel_stat';
inputyId['konatel_stat']='0_0_8_4_3';
inputyTypy['0_0_8_4_3']='cislo';
inputyUpperCase['0_0_8_4_3']='1';

inputy.push('0_0_8_4_4');
inputyMena['0_0_8_4_4']='konatel_tel_predvolba';
inputyId['konatel_tel_predvolba']='0_0_8_4_4';
inputyTypy['0_0_8_4_4']='cislo';
inputyUpperCase['0_0_8_4_4']='1';

inputy.push('0_0_8_4_5');
inputyMena['0_0_8_4_5']='konatel_tel_cislo';
inputyId['konatel_tel_cislo']='0_0_8_4_5';
inputyTypy['0_0_8_4_5']='cislo';
inputyUpperCase['0_0_8_4_5']='1';

inputy.push('0_0_8_4_6');
inputyMena['0_0_8_4_6']='konatel_fax_predvolba';
inputyId['konatel_fax_predvolba']='0_0_8_4_6';
inputyTypy['0_0_8_4_6']='cislo';
inputyUpperCase['0_0_8_4_6']='1';

inputy.push('0_0_8_4_7');
inputyMena['0_0_8_4_7']='konatel_fax_cislo';
inputyId['konatel_fax_cislo']='0_0_8_4_7';
inputyTypy['0_0_8_4_7']='cislo';
inputyUpperCase['0_0_8_4_7']='1';

inputy.push('0_0_9');
inputyMena['0_0_9']='pocet_priloh';
inputyId['pocet_priloh']='0_0_9';
inputyTypy['0_0_9']='cislo';
inputyUpperCase['0_0_9']='1';

inputy.push('0_0_10_0_0');
inputyMena['0_0_10_0_0']='datum_od_den';
inputyId['datum_od_den']='0_0_10_0_0';
inputyTypy['0_0_10_0_0']='cislo';
inputyUpperCase['0_0_10_0_0']='1';

inputy.push('0_0_10_0_1');
inputyMena['0_0_10_0_1']='datum_od_mesiac';
inputyId['datum_od_mesiac']='0_0_10_0_1';
inputyTypy['0_0_10_0_1']='cislo';
inputyUpperCase['0_0_10_0_1']='1';

inputy.push('0_0_10_1_0');
inputyMena['0_0_10_1_0']='datum_do_den';
inputyId['datum_do_den']='0_0_10_1_0';
inputyTypy['0_0_10_1_0']='cislo';
inputyUpperCase['0_0_10_1_0']='1';

inputy.push('0_0_10_1_1');
inputyMena['0_0_10_1_1']='datum_do_mesiac';
inputyId['datum_do_mesiac']='0_0_10_1_1';
inputyTypy['0_0_10_1_1']='cislo';
inputyUpperCase['0_0_10_1_1']='1';

inputy.push('0_0_10_2');
inputyMena['0_0_10_2']='rok';
inputyId['rok']='0_0_10_2';
inputyTypy['0_0_10_2']='cislo';
inputyUpperCase['0_0_10_2']='1';

inputy.push('0_0_11_0');
inputyMena['0_0_11_0']='datum_den';
inputyId['datum_den']='0_0_11_0';
inputyTypy['0_0_11_0']='cislo';
inputyUpperCase['0_0_11_0']='1';

inputy.push('0_0_11_1');
inputyMena['0_0_11_1']='datum_mesiac';
inputyId['datum_mesiac']='0_0_11_1';
inputyTypy['0_0_11_1']='cislo';
inputyUpperCase['0_0_11_1']='1';

inputy.push('0_0_11_2');
inputyMena['0_0_11_2']='datum_rok';
inputyId['datum_rok']='0_0_11_2';
inputyTypy['0_0_11_2']='cislo';
inputyUpperCase['0_0_11_2']='1';

inputy.push('0_0_12');
inputyMena['0_0_12']='zostavil';
inputyId['zostavil']='0_0_12';
inputyTypy['0_0_12']='cislo';
inputyUpperCase['0_0_12']='1';

inputy.push('0_1_0_1');
inputyMena['0_1_0_1']='r100';
inputyId['r100']='0_1_0_1';
inputyTypy['0_1_0_1']='znamienko';
inputyUpperCase['0_1_0_1']='1';

inputy.push('0_1_0_0');
inputyMena['0_1_0_0']='r100_z';
inputyId['r100_z']='0_1_0_0';
inputyTypy['0_1_0_0']='cislo';
inputyUpperCase['0_1_0_0']='1';

inputy.push('0_1_1');
inputyMena['0_1_1']='r110';
inputyId['r110']='0_1_1';
inputyTypy['0_1_1']='cislo';
inputyUpperCase['0_1_1']='1';

inputy.push('0_1_2');
inputyMena['0_1_2']='r120';
inputyId['r120']='0_1_2';
inputyTypy['0_1_2']='cislo';
inputyUpperCase['0_1_2']='1';

inputy.push('0_1_3');
inputyMena['0_1_3']='r130';
inputyId['r130']='0_1_3';
inputyTypy['0_1_3']='cislo';
inputyUpperCase['0_1_3']='1';

inputy.push('0_1_4');
inputyMena['0_1_4']='r140';
inputyId['r140']='0_1_4';
inputyTypy['0_1_4']='cislo';
inputyUpperCase['0_1_4']='1';

inputy.push('0_1_5');
inputyMena['0_1_5']='r150';
inputyId['r150']='0_1_5';
inputyTypy['0_1_5']='cislo';
inputyUpperCase['0_1_5']='1';

inputy.push('0_1_6');
inputyMena['0_1_6']='r160';
inputyId['r160']='0_1_6';
inputyTypy['0_1_6']='cislo';
inputyUpperCase['0_1_6']='1';

inputy.push('0_1_7');
inputyMena['0_1_7']='r170';
inputyId['r170']='0_1_7';
inputyTypy['0_1_7']='cislo';
inputyUpperCase['0_1_7']='1';

inputy.push('0_1_8');
inputyMena['0_1_8']='r180';
inputyId['r180']='0_1_8';
inputyTypy['0_1_8']='cislo';
inputyUpperCase['0_1_8']='1';

inputy.push('0_1_9');
inputyMena['0_1_9']='r190';
inputyId['r190']='0_1_9';
inputyTypy['0_1_9']='cislo';
inputyUpperCase['0_1_9']='1';

inputy.push('0_1_10');
inputyMena['0_1_10']='r200';
inputyId['r200']='0_1_10';
inputyTypy['0_1_10']='cislo';
inputyUpperCase['0_1_10']='1';

inputy.push('0_1_11');
inputyMena['0_1_11']='r210';
inputyId['r210']='0_1_11';
inputyTypy['0_1_11']='cislo';
inputyUpperCase['0_1_11']='1';

inputy.push('0_1_12');
inputyMena['0_1_12']='r220';
inputyId['r220']='0_1_12';
inputyTypy['0_1_12']='cislo';
inputyUpperCase['0_1_12']='1';

inputy.push('0_1_13');
inputyMena['0_1_13']='r230';
inputyId['r230']='0_1_13';
inputyTypy['0_1_13']='cislo';
inputyUpperCase['0_1_13']='1';

inputy.push('0_1_14');
inputyMena['0_1_14']='r240';
inputyId['r240']='0_1_14';
inputyTypy['0_1_14']='cislo';
inputyUpperCase['0_1_14']='1';

inputy.push('0_1_15');
inputyMena['0_1_15']='r250';
inputyId['r250']='0_1_15';
inputyTypy['0_1_15']='cislo';
inputyUpperCase['0_1_15']='1';

inputy.push('0_1_16');
inputyMena['0_1_16']='r260';
inputyId['r260']='0_1_16';
inputyTypy['0_1_16']='cislo';
inputyUpperCase['0_1_16']='1';

inputy.push('0_1_17');
inputyMena['0_1_17']='r270';
inputyId['r270']='0_1_17';
inputyTypy['0_1_17']='cislo';
inputyUpperCase['0_1_17']='1';

inputy.push('0_1_18');
inputyMena['0_1_18']='r280';
inputyId['r280']='0_1_18';
inputyTypy['0_1_18']='cislo';
inputyUpperCase['0_1_18']='1';

inputy.push('0_1_19');
inputyMena['0_1_19']='r290';
inputyId['r290']='0_1_19';
inputyTypy['0_1_19']='cislo';
inputyUpperCase['0_1_19']='1';

inputy.push('0_1_20');
inputyMena['0_1_20']='r300';
inputyId['r300']='0_1_20';
inputyTypy['0_1_20']='cislo';
inputyUpperCase['0_1_20']='1';

inputy.push('0_1_21');
inputyMena['0_1_21']='r310';
inputyId['r310']='0_1_21';
inputyTypy['0_1_21']='znamienko';
inputyUpperCase['0_1_21']='1';

inputy.push('r310_z');
inputyMena['r310_z']='r310_z';
inputyId['r310_z']='r310_z';
inputyTypy['r310_z']='cislo';
inputyUpperCase['r310_z']='1';

inputy.push('0_1_22');
inputyMena['0_1_22']='r320';
inputyId['r320']='0_1_22';
inputyTypy['0_1_22']='znamienko';
inputyUpperCase['0_1_22']='1';

inputy.push('r320_z');
inputyMena['r320_z']='r320_z';
inputyId['r320_z']='r320_z';
inputyTypy['r320_z']='cislo';
inputyUpperCase['r320_z']='1';


inputy.push('0_1_23');
inputyMena['0_1_23']='r330';
inputyId['r330']='0_1_23';
inputyTypy['0_1_23']='cislo';
inputyUpperCase['0_1_23']='1';

inputy.push('0_1_24');
inputyMena['0_1_24']='r400';
inputyId['r400']='0_1_24';
inputyTypy['0_1_24']='znamienko';
inputyUpperCase['0_1_24']='1';

inputy.push('r400_z');
inputyMena['r400_z']='r400_z';
inputyId['r400_z']='r400_z';
inputyTypy['r400_z']='cislo';
inputyUpperCase['r400_z']='1';

inputy.push('0_1_25');
inputyMena['0_1_25']='r410';
inputyId['r410']='0_1_25';
inputyTypy['0_1_25']='cislo';
inputyUpperCase['0_1_25']='1';

inputy.push('0_1_26');
inputyMena['0_1_26']='r420';
inputyId['r420']='0_1_26';
inputyTypy['0_1_26']='cislo';
inputyUpperCase['0_1_26']='1';

inputy.push('0_1_27');
inputyMena['0_1_27']='r430';
inputyId['r430']='0_1_27';
inputyTypy['0_1_27']='cislo';
inputyUpperCase['0_1_27']='1';

inputy.push('0_1_28');
inputyMena['0_1_28']='r440';
inputyId['r440']='0_1_28';
inputyTypy['0_1_28']='cislo';
inputyUpperCase['0_1_28']='1';

inputy.push('0_1_29');
inputyMena['0_1_29']='r450';
inputyId['r450']='0_1_29';
inputyTypy['0_1_29']='cislo';
inputyUpperCase['0_1_29']='1';

inputy.push('0_1_30');
inputyMena['0_1_30']='r460';
inputyId['r460']='0_1_30';
inputyTypy['0_1_30']='cislo';
inputyUpperCase['0_1_30']='1';

inputy.push('0_1_31');
inputyMena['0_1_31']='r470';
inputyId['r470']='0_1_31';
inputyTypy['0_1_31']='cislo';
inputyUpperCase['0_1_31']='1';

inputy.push('0_1_32');
inputyMena['0_1_32']='r500';
inputyId['r500']='0_1_32';
inputyTypy['0_1_32']='cislo';
inputyUpperCase['0_1_32']='1';

inputy.push('0_1_33');
inputyMena['0_1_33']='r510';
inputyId['r510']='0_1_33';
inputyTypy['0_1_33']='cislo';
inputyUpperCase['0_1_33']='1';

inputy.push('0_1_34');
inputyMena['0_1_34']='r600';
inputyId['r600']='0_1_34';
inputyTypy['0_1_34']='cislo';
inputyUpperCase['0_1_34']='1';

inputy.push('0_1_35_0');
inputyMena['0_1_35_0']='r610_text';
inputyId['r610_text']='0_1_35_0';
inputyTypy['0_1_35_0']='cislo';
inputyUpperCase['0_1_35_0']='1';

inputy.push('0_1_35_1');
inputyMena['0_1_35_1']='r610';
inputyId['r610']='0_1_35_1';
inputyTypy['0_1_35_1']='cislo';
inputyUpperCase['0_1_35_1']='1';

inputy.push('0_1_36_0');
inputyMena['0_1_36_0']='r620_text';
inputyId['r620_text']='0_1_36_0';
inputyTypy['0_1_36_0']='cislo';
inputyUpperCase['0_1_36_0']='1';

inputy.push('0_1_36_1');
inputyMena['0_1_36_1']='r620';
inputyId['r620']='0_1_36_1';
inputyTypy['0_1_36_1']='cislo';
inputyUpperCase['0_1_36_1']='1';

inputy.push('0_1_37');
inputyMena['0_1_37']='r630';
inputyId['r630']='0_1_37';
inputyTypy['0_1_37']='cislo';
inputyUpperCase['0_1_37']='1';

inputy.push('0_1_38');
inputyMena['0_1_38']='r640';
inputyId['r640']='0_1_38';
inputyTypy['0_1_38']='cislo';
inputyUpperCase['0_1_38']='1';

inputy.push('0_1_39');
inputyMena['0_1_39']='r650';
inputyId['r650']='0_1_39';
inputyTypy['0_1_39']='cislo';
inputyUpperCase['0_1_39']='1';

inputy.push('0_1_40');
inputyMena['0_1_40']='r700';
inputyId['r700']='0_1_40';
inputyTypy['0_1_40']='cislo';
inputyUpperCase['0_1_40']='1';

inputy.push('0_1_41');
inputyMena['0_1_41']='r710';
inputyId['r710']='0_1_41';
inputyTypy['0_1_41']='cislo';
inputyUpperCase['0_1_41']='1';

inputy.push('0_1_42');
inputyMena['0_1_42']='r800';
inputyId['r800']='0_1_42';
inputyTypy['0_1_42']='cislo';
inputyUpperCase['0_1_42']='1';

inputy.push('0_1_43_0');
inputyMena['0_1_43_0']='r810_den';
inputyId['r810_den']='0_1_43_0';
inputyTypy['0_1_43_0']='cislo';
inputyUpperCase['0_1_43_0']='1';

inputy.push('0_1_43_1');
inputyMena['0_1_43_1']='r810_mesiac';
inputyId['r810_mesiac']='0_1_43_1';
inputyTypy['0_1_43_1']='cislo';
inputyUpperCase['0_1_43_1']='1';

inputy.push('0_1_43_2');
inputyMena['0_1_43_2']='r810_rok';
inputyId['r810_rok']='0_1_43_2';
inputyTypy['0_1_43_2']='cislo';
inputyUpperCase['0_1_43_2']='1';

inputy.push('0_1_43_3');
inputyMena['0_1_43_3']='r810';
inputyId['r810']='0_1_43_3';
inputyTypy['0_1_43_3']='cislo';
inputyUpperCase['0_1_43_3']='1';

inputy.push('0_1_44_0');
inputyMena['0_1_44_0']='r820_den';
inputyId['r820_den']='0_1_44_0';
inputyTypy['0_1_44_0']='cislo';
inputyUpperCase['0_1_44_0']='1';

inputy.push('0_1_44_1');
inputyMena['0_1_44_1']='r820_mesiac';
inputyId['r820_mesiac']='0_1_44_1';
inputyTypy['0_1_44_1']='cislo';
inputyUpperCase['0_1_44_1']='1';

inputy.push('0_1_44_2');
inputyMena['0_1_44_2']='r820_rok';
inputyId['r820_rok']='0_1_44_2';
inputyTypy['0_1_44_2']='cislo';
inputyUpperCase['0_1_44_2']='1';

inputy.push('0_1_44_3');
inputyMena['0_1_44_3']='r820';
inputyId['r820']='0_1_44_3';
inputyTypy['0_1_44_3']='cislo';
inputyUpperCase['0_1_44_3']='1';

inputy.push('0_1_45');
inputyMena['0_1_45']='r830';
inputyId['r830']='0_1_45';
inputyTypy['0_1_45']='cislo';
inputyUpperCase['0_1_45']='1';

inputy.push('0_1_46');
inputyMena['0_1_46']='r840';
inputyId['r840']='0_1_46';
inputyTypy['0_1_46']='cislo';
inputyUpperCase['0_1_46']='1';

inputy.push('0_1_47');
inputyMena['0_1_47']='r850';
inputyId['r850']='0_1_47';
inputyTypy['0_1_47']='cislo';
inputyUpperCase['0_1_47']='1';

inputy.push('0_1_48_0');
inputyMena['0_1_48_0']='r900_den';
inputyId['r900_den']='0_1_48_0';
inputyTypy['0_1_48_0']='cislo';
inputyUpperCase['0_1_48_0']='1';

inputy.push('0_1_48_1');
inputyMena['0_1_48_1']='r900_mesiac';
inputyId['r900_mesiac']='0_1_48_1';
inputyTypy['0_1_48_1']='cislo';
inputyUpperCase['0_1_48_1']='1';

inputy.push('0_1_48_2');
inputyMena['0_1_48_2']='r900_rok';
inputyId['r900_rok']='0_1_48_2';
inputyTypy['0_1_48_2']='cislo';
inputyUpperCase['0_1_48_2']='1';

inputy.push('0_1_48_3');
inputyMena['0_1_48_3']='r900';
inputyId['r900']='0_1_48_3';
inputyTypy['0_1_48_3']='znamienko';
inputyUpperCase['0_1_48_3']='1';

inputy.push('r900_z');
inputyMena['r900_z']='r900_z';
inputyId['r900_z']='r900_z';
inputyTypy['r900_z']='cislo';
inputyUpperCase['r900_z']='1';

inputy.push('0_1_49');
inputyMena['0_1_49']='r901';
inputyId['r901']='0_1_49';
inputyTypy['0_1_49']='cislo';
inputyUpperCase['0_1_49']='1';

inputy.push('0_1_50');
inputyMena['0_1_50']='r902';
inputyId['r902']='0_1_50';
inputyTypy['0_1_50']='znamienko';
inputyUpperCase['0_1_50']='1';

inputy.push('r902_z');
inputyMena['r902_z']='r902_z';
inputyId['r902_z']='r902_z';
inputyTypy['r902_z']='cislo';
inputyUpperCase['r902_z']='1';

inputy.push('0_1_51');
inputyMena['0_1_51']='r910';
inputyId['r910']='0_1_51';
inputyTypy['0_1_51']='cislo';
inputyUpperCase['0_1_51']='1';

inputy.push('0_1_52_0');
inputyMena['0_1_52_0']='ddp_den';
inputyId['ddp_den']='0_1_52_0';
inputyTypy['0_1_52_0']='cislo';
inputyUpperCase['0_1_52_0']='1';

inputy.push('0_1_52_1');
inputyMena['0_1_52_1']='ddp_mesiac';
inputyId['ddp_mesiac']='0_1_52_1';
inputyTypy['0_1_52_1']='cislo';
inputyUpperCase['0_1_52_1']='1';

inputy.push('0_1_52_2');
inputyMena['0_1_52_2']='ddp_rok';
inputyId['ddp_rok']='0_1_52_2';
inputyTypy['0_1_52_2']='cislo';
inputyUpperCase['0_1_52_2']='1';

inputy.push('0_1_53');
inputyMena['0_1_53']='r920';
inputyId['r920']='0_1_53';
inputyTypy['0_1_53']='cislo';
inputyUpperCase['0_1_53']='1';

inputy.push('0_1_54');
inputyMena['0_1_54']='r930';
inputyId['r930']='0_1_54';
inputyTypy['0_1_54']='cislo';
inputyUpperCase['0_1_54']='1';

inputy.push('0_1_55');
inputyMena['0_1_55']='r940';
inputyId['r940']='0_1_55';
inputyTypy['0_1_55']='cislo';
inputyUpperCase['0_1_55']='1';

inputy.push('0_1_56');
inputyMena['0_1_56']='r950';
inputyId['r950']='0_1_56';
inputyTypy['0_1_56']='cislo';
inputyUpperCase['0_1_56']='1';

inputy.push('0_1_57');
inputyMena['0_1_57']='r960';
inputyId['r960']='0_1_57';
inputyTypy['0_1_57']='cislo';
inputyUpperCase['0_1_57']='1';

inputy.push('0_1_58');
inputyMena['0_1_58']='r970';
inputyId['r970']='0_1_58';
inputyTypy['0_1_58']='znamienko';
inputyUpperCase['0_1_58']='1';

inputy.push('r970_z');
inputyMena['r970_z']='r970_z';
inputyId['r970_z']='r970_z';
inputyTypy['r970_z']='cislo';
inputyUpperCase['r970_z']='1';

inputy.push('0_1_59_0');
inputyMena['0_1_59_0']='ta_r01';
inputyId['ta_r01']='0_1_59_0';
inputyTypy['0_1_59_0']='cislo';
inputyUpperCase['0_1_59_0']='1';

inputy.push('0_1_59_1');
inputyMena['0_1_59_1']='ta_r02';
inputyId['ta_r02']='0_1_59_1';
inputyTypy['0_1_59_1']='cislo';
inputyUpperCase['0_1_59_1']='1';

inputy.push('0_1_59_2');
inputyMena['0_1_59_2']='ta_r03';
inputyId['ta_r03']='0_1_59_2';
inputyTypy['0_1_59_2']='cislo';
inputyUpperCase['0_1_59_2']='1';

inputy.push('0_1_59_3');
inputyMena['0_1_59_3']='ta_r04';
inputyId['ta_r04']='0_1_59_3';
inputyTypy['0_1_59_3']='cislo';
inputyUpperCase['0_1_59_3']='1';

inputy.push('0_1_59_4');
inputyMena['0_1_59_4']='ta_r05';
inputyId['ta_r05']='0_1_59_4';
inputyTypy['0_1_59_4']='cislo';
inputyUpperCase['0_1_59_4']='1';

inputy.push('0_1_59_5');
inputyMena['0_1_59_5']='ta_r06';
inputyId['ta_r06']='0_1_59_5';
inputyTypy['0_1_59_5']='cislo';
inputyUpperCase['0_1_59_5']='1';

inputy.push('0_1_59_6');
inputyMena['0_1_59_6']='ta_r07';
inputyId['ta_r07']='0_1_59_6';
inputyTypy['0_1_59_6']='cislo';
inputyUpperCase['0_1_59_6']='1';

inputy.push('0_1_59_7');
inputyMena['0_1_59_7']='ta_r08';
inputyId['ta_r08']='0_1_59_7';
inputyTypy['0_1_59_7']='cislo';
inputyUpperCase['0_1_59_7']='1';

inputy.push('0_1_59_8');
inputyMena['0_1_59_8']='ta_r09';
inputyId['ta_r09']='0_1_59_8';
inputyTypy['0_1_59_8']='cislo';
inputyUpperCase['0_1_59_8']='1';

inputy.push('0_1_59_9');
inputyMena['0_1_59_9']='ta_r10';
inputyId['ta_r10']='0_1_59_9';
inputyTypy['0_1_59_9']='cislo';
inputyUpperCase['0_1_59_9']='1';

inputy.push('0_1_59_10');
inputyMena['0_1_59_10']='ta_r11';
inputyId['ta_r11']='0_1_59_10';
inputyTypy['0_1_59_10']='cislo';
inputyUpperCase['0_1_59_10']='1';

inputy.push('0_1_59_11');
inputyMena['0_1_59_11']='ta_r12';
inputyId['ta_r12']='0_1_59_11';
inputyTypy['0_1_59_11']='cislo';
inputyUpperCase['0_1_59_11']='1';

inputy.push('0_1_59_12');
inputyMena['0_1_59_12']='ta_r13';
inputyId['ta_r13']='0_1_59_12';
inputyTypy['0_1_59_12']='cislo';
inputyUpperCase['0_1_59_12']='1';

inputy.push('0_1_59_13');
inputyMena['0_1_59_13']='ta_r14';
inputyId['ta_r14']='0_1_59_13';
inputyTypy['0_1_59_13']='cislo';
inputyUpperCase['0_1_59_13']='1';

inputy.push('0_1_59_14');
inputyMena['0_1_59_14']='ta_r15';
inputyId['ta_r15']='0_1_59_14';
inputyTypy['0_1_59_14']='cislo';
inputyUpperCase['0_1_59_14']='1';

inputy.push('0_1_59_15');
inputyMena['0_1_59_15']='ta_r16';
inputyId['ta_r16']='0_1_59_15';
inputyTypy['0_1_59_15']='cislo';
inputyUpperCase['0_1_59_15']='1';

inputy.push('0_1_59_16');
inputyMena['0_1_59_16']='ta_r17';
inputyId['ta_r17']='0_1_59_16';
inputyTypy['0_1_59_16']='cislo';
inputyUpperCase['0_1_59_16']='1';

inputy.push('0_1_59_17');
inputyMena['0_1_59_17']='ta_r18';
inputyId['ta_r18']='0_1_59_17';
inputyTypy['0_1_59_17']='cislo';
inputyUpperCase['0_1_59_17']='1';

inputy.push('0_1_59_18');
inputyMena['0_1_59_18']='ta_r19';
inputyId['ta_r19']='0_1_59_18';
inputyTypy['0_1_59_18']='cislo';
inputyUpperCase['0_1_59_18']='1';

inputy.push('0_1_60_0');
inputyMena['0_1_60_0']='tb_r01';
inputyId['tb_r01']='0_1_60_0';
inputyTypy['0_1_60_0']='cislo';
inputyUpperCase['0_1_60_0']='1';

inputy.push('0_1_60_1');
inputyMena['0_1_60_1']='tb_r02';
inputyId['tb_r02']='0_1_60_1';
inputyTypy['0_1_60_1']='cislo';
inputyUpperCase['0_1_60_1']='1';

inputy.push('0_1_60_2');
inputyMena['0_1_60_2']='tb_r03';
inputyId['tb_r03']='0_1_60_2';
inputyTypy['0_1_60_2']='cislo';
inputyUpperCase['0_1_60_2']='1';

inputy.push('0_1_61_0');
inputyMena['0_1_61_0']='tc_r01';
inputyId['tc_r01']='0_1_61_0';
inputyTypy['0_1_61_0']='cislo';
inputyUpperCase['0_1_61_0']='1';

inputy.push('0_1_61_1');
inputyMena['0_1_61_1']='tc_r02';
inputyId['tc_r02']='0_1_61_1';
inputyTypy['0_1_61_1']='cislo';
inputyUpperCase['0_1_61_1']='1';

inputy.push('0_1_61_2');
inputyMena['0_1_61_2']='tc_r03';
inputyId['tc_r03']='0_1_61_2';
inputyTypy['0_1_61_2']='cislo';
inputyUpperCase['0_1_61_2']='1';

inputy.push('0_1_62_0');
inputyMena['0_1_62_0']='td_r01';
inputyId['td_r01']='0_1_62_0';
inputyTypy['0_1_62_0']='cislo';
inputyUpperCase['0_1_62_0']='1';

inputy.push('0_1_62_1');
inputyMena['0_1_62_1']='td_r02';
inputyId['td_r02']='0_1_62_1';
inputyTypy['0_1_62_1']='cislo';
inputyUpperCase['0_1_62_1']='1';

inputy.push('0_1_62_2');
inputyMena['0_1_62_2']='td_r03';
inputyId['td_r03']='0_1_62_2';
inputyTypy['0_1_62_2']='cislo';
inputyUpperCase['0_1_62_2']='1';

inputy.push('0_1_62_3');
inputyMena['0_1_62_3']='td_r04';
inputyId['td_r04']='0_1_62_3';
inputyTypy['0_1_62_3']='cislo';
inputyUpperCase['0_1_62_3']='1';

inputy.push('0_1_62_4');
inputyMena['0_1_62_4']='td_r05';
inputyId['td_r05']='0_1_62_4';
inputyTypy['0_1_62_4']='cislo';
inputyUpperCase['0_1_62_4']='1';

inputy.push('0_1_63_0');
inputyMena['0_1_63_0']='te_r01';
inputyId['te_r01']='0_1_63_0';
inputyTypy['0_1_63_0']='cislo';
inputyUpperCase['0_1_63_0']='1';

inputy.push('0_1_63_1');
inputyMena['0_1_63_1']='te_r02';
inputyId['te_r02']='0_1_63_1';
inputyTypy['0_1_63_1']='cislo';
inputyUpperCase['0_1_63_1']='1';

inputy.push('0_1_63_2');
inputyMena['0_1_63_2']='te_r03';
inputyId['te_r03']='0_1_63_2';
inputyTypy['0_1_63_2']='cislo';
inputyUpperCase['0_1_63_2']='1';

inputy.push('0_1_63_3');
inputyMena['0_1_63_3']='te_r04';
inputyId['te_r04']='0_1_63_3';
inputyTypy['0_1_63_3']='cislo';
inputyUpperCase['0_1_63_3']='1';

inputy.push('0_1_63_4');
inputyMena['0_1_63_4']='te_r05';
inputyId['te_r05']='0_1_63_4';
inputyTypy['0_1_63_4']='cislo';
inputyUpperCase['0_1_63_4']='1';

inputy.push('0_1_63_5');
inputyMena['0_1_63_5']='te_r06';
inputyId['te_r06']='0_1_63_5';
inputyTypy['0_1_63_5']='cislo';
inputyUpperCase['0_1_63_5']='1';

inputy.push('0_1_64_0_0_0');
inputyMena['0_1_64_0_0_0']='tf_r01_s01';
inputyId['tf_r01_s01']='0_1_64_0_0_0';
inputyTypy['0_1_64_0_0_0']='cislo';
inputyUpperCase['0_1_64_0_0_0']='1';

inputy.push('0_1_64_0_0_1');
inputyMena['0_1_64_0_0_1']='tf_r01_s02';
inputyId['tf_r01_s02']='0_1_64_0_0_1';
inputyTypy['0_1_64_0_0_1']='cislo';
inputyUpperCase['0_1_64_0_0_1']='1';

inputy.push('0_1_64_0_0_2');
inputyMena['0_1_64_0_0_2']='tf_r01_s03';
inputyId['tf_r01_s03']='0_1_64_0_0_2';
inputyTypy['0_1_64_0_0_2']='cislo';
inputyUpperCase['0_1_64_0_0_2']='1';

inputy.push('0_1_64_0_0_3');
inputyMena['0_1_64_0_0_3']='tf_r01_s04';
inputyId['tf_r01_s04']='0_1_64_0_0_3';
inputyTypy['0_1_64_0_0_3']='cislo';
inputyUpperCase['0_1_64_0_0_3']='1';

inputy.push('0_1_64_0_1_0');
inputyMena['0_1_64_0_1_0']='tf_r02_s01';
inputyId['tf_r02_s01']='0_1_64_0_1_0';
inputyTypy['0_1_64_0_1_0']='cislo';
inputyUpperCase['0_1_64_0_1_0']='1';

inputy.push('0_1_64_0_1_1');
inputyMena['0_1_64_0_1_1']='tf_r02_s02';
inputyId['tf_r02_s02']='0_1_64_0_1_1';
inputyTypy['0_1_64_0_1_1']='cislo';
inputyUpperCase['0_1_64_0_1_1']='1';

inputy.push('0_1_64_0_1_2');
inputyMena['0_1_64_0_1_2']='tf_r02_s03';
inputyId['tf_r02_s03']='0_1_64_0_1_2';
inputyTypy['0_1_64_0_1_2']='cislo';
inputyUpperCase['0_1_64_0_1_2']='1';

inputy.push('0_1_64_0_1_3');
inputyMena['0_1_64_0_1_3']='tf_r02_s04';
inputyId['tf_r02_s04']='0_1_64_0_1_3';
inputyTypy['0_1_64_0_1_3']='cislo';
inputyUpperCase['0_1_64_0_1_3']='1';

inputy.push('0_1_64_0_2_0');
inputyMena['0_1_64_0_2_0']='tf_r03_s01';
inputyId['tf_r03_s01']='0_1_64_0_2_0';
inputyTypy['0_1_64_0_2_0']='cislo';
inputyUpperCase['0_1_64_0_2_0']='1';

inputy.push('0_1_64_0_2_1');
inputyMena['0_1_64_0_2_1']='tf_r03_s02';
inputyId['tf_r03_s02']='0_1_64_0_2_1';
inputyTypy['0_1_64_0_2_1']='cislo';
inputyUpperCase['0_1_64_0_2_1']='1';

inputy.push('0_1_64_0_2_2');
inputyMena['0_1_64_0_2_2']='tf_r03_s03';
inputyId['tf_r03_s03']='0_1_64_0_2_2';
inputyTypy['0_1_64_0_2_2']='cislo';
inputyUpperCase['0_1_64_0_2_2']='1';

inputy.push('0_1_64_0_2_3');
inputyMena['0_1_64_0_2_3']='tf_r03_s04';
inputyId['tf_r03_s04']='0_1_64_0_2_3';
inputyTypy['0_1_64_0_2_3']='cislo';
inputyUpperCase['0_1_64_0_2_3']='1';

inputy.push('0_1_64_0_3_0');
inputyMena['0_1_64_0_3_0']='tf_r04_s01';
inputyId['tf_r04_s01']='0_1_64_0_3_0';
inputyTypy['0_1_64_0_3_0']='cislo';
inputyUpperCase['0_1_64_0_3_0']='1';

inputy.push('0_1_64_0_3_1');
inputyMena['0_1_64_0_3_1']='tf_r04_s02';
inputyId['tf_r04_s02']='0_1_64_0_3_1';
inputyTypy['0_1_64_0_3_1']='cislo';
inputyUpperCase['0_1_64_0_3_1']='1';

inputy.push('0_1_64_0_3_2');
inputyMena['0_1_64_0_3_2']='tf_r04_s03';
inputyId['tf_r04_s03']='0_1_64_0_3_2';
inputyTypy['0_1_64_0_3_2']='cislo';
inputyUpperCase['0_1_64_0_3_2']='1';

inputy.push('0_1_64_0_3_3');
inputyMena['0_1_64_0_3_3']='tf_r04_s04';
inputyId['tf_r04_s04']='0_1_64_0_3_3';
inputyTypy['0_1_64_0_3_3']='cislo';
inputyUpperCase['0_1_64_0_3_3']='1';

inputy.push('0_1_64_0_4_0');
inputyMena['0_1_64_0_4_0']='tf_r05_s01';
inputyId['tf_r05_s01']='0_1_64_0_4_0';
inputyTypy['0_1_64_0_4_0']='cislo';
inputyUpperCase['0_1_64_0_4_0']='1';

inputy.push('0_1_64_0_4_1');
inputyMena['0_1_64_0_4_1']='tf_r05_s02';
inputyId['tf_r05_s02']='0_1_64_0_4_1';
inputyTypy['0_1_64_0_4_1']='cislo';
inputyUpperCase['0_1_64_0_4_1']='1';

inputy.push('0_1_64_0_4_2');
inputyMena['0_1_64_0_4_2']='tf_r05_s03';
inputyId['tf_r05_s03']='0_1_64_0_4_2';
inputyTypy['0_1_64_0_4_2']='cislo';
inputyUpperCase['0_1_64_0_4_2']='1';

inputy.push('0_1_64_0_4_3');
inputyMena['0_1_64_0_4_3']='tf_r05_s04';
inputyId['tf_r05_s04']='0_1_64_0_4_3';
inputyTypy['0_1_64_0_4_3']='cislo';
inputyUpperCase['0_1_64_0_4_3']='1';

inputy.push('0_1_64_0_5_0');
inputyMena['0_1_64_0_5_0']='tf_r06_s01';
inputyId['tf_r06_s01']='0_1_64_0_5_0';
inputyTypy['0_1_64_0_5_0']='cislo';
inputyUpperCase['0_1_64_0_5_0']='1';

inputy.push('0_1_64_0_5_1');
inputyMena['0_1_64_0_5_1']='tf_r06_s02';
inputyId['tf_r06_s02']='0_1_64_0_5_1';
inputyTypy['0_1_64_0_5_1']='cislo';
inputyUpperCase['0_1_64_0_5_1']='1';

inputy.push('0_1_64_0_5_2');
inputyMena['0_1_64_0_5_2']='tf_r06_s03';
inputyId['tf_r06_s03']='0_1_64_0_5_2';
inputyTypy['0_1_64_0_5_2']='cislo';
inputyUpperCase['0_1_64_0_5_2']='1';

inputy.push('0_1_64_0_5_3');
inputyMena['0_1_64_0_5_3']='tf_r06_s04';
inputyId['tf_r06_s04']='0_1_64_0_5_3';
inputyTypy['0_1_64_0_5_3']='cislo';
inputyUpperCase['0_1_64_0_5_3']='1';

inputy.push('0_1_64_0_6_0');
inputyMena['0_1_64_0_6_0']='tf_r07_s01';
inputyId['tf_r07_s01']='0_1_64_0_6_0';
inputyTypy['0_1_64_0_6_0']='cislo';
inputyUpperCase['0_1_64_0_6_0']='1';

inputy.push('0_1_64_0_6_1');
inputyMena['0_1_64_0_6_1']='tf_r07_s02';
inputyId['tf_r07_s02']='0_1_64_0_6_1';
inputyTypy['0_1_64_0_6_1']='cislo';
inputyUpperCase['0_1_64_0_6_1']='1';

inputy.push('0_1_64_0_6_2');
inputyMena['0_1_64_0_6_2']='tf_r07_s03';
inputyId['tf_r07_s03']='0_1_64_0_6_2';
inputyTypy['0_1_64_0_6_2']='cislo';
inputyUpperCase['0_1_64_0_6_2']='1';

inputy.push('0_1_64_0_6_3');
inputyMena['0_1_64_0_6_3']='tf_r07_s04';
inputyId['tf_r07_s04']='0_1_64_0_6_3';
inputyTypy['0_1_64_0_6_3']='cislo';
inputyUpperCase['0_1_64_0_6_3']='1';

inputy.push('0_1_64_0_7_0');
inputyMena['0_1_64_0_7_0']='tf_r08_s01';
inputyId['tf_r08_s01']='0_1_64_0_7_0';
inputyTypy['0_1_64_0_7_0']='cislo';
inputyUpperCase['0_1_64_0_7_0']='1';

inputy.push('0_1_64_0_7_1');
inputyMena['0_1_64_0_7_1']='tf_r08_s02';
inputyId['tf_r08_s02']='0_1_64_0_7_1';
inputyTypy['0_1_64_0_7_1']='cislo';
inputyUpperCase['0_1_64_0_7_1']='1';

inputy.push('0_1_64_0_7_2');
inputyMena['0_1_64_0_7_2']='tf_r08_s03';
inputyId['tf_r08_s03']='0_1_64_0_7_2';
inputyTypy['0_1_64_0_7_2']='cislo';
inputyUpperCase['0_1_64_0_7_2']='1';

inputy.push('0_1_64_0_7_3');
inputyMena['0_1_64_0_7_3']='tf_r08_s04';
inputyId['tf_r08_s04']='0_1_64_0_7_3';
inputyTypy['0_1_64_0_7_3']='cislo';
inputyUpperCase['0_1_64_0_7_3']='1';

inputy.push('0_1_64_1_0_1');
inputyMena['0_1_64_1_0_1']='tf_r01_s05';
inputyId['tf_r01_s05']='0_1_64_1_0_1';
inputyTypy['0_1_64_1_0_1']='cislo';
inputyUpperCase['0_1_64_1_0_1']='1';

inputy.push('0_1_64_1_0_2');
inputyMena['0_1_64_1_0_2']='tf_r01_s06';
inputyId['tf_r01_s06']='0_1_64_1_0_2';
inputyTypy['0_1_64_1_0_2']='cislo';
inputyUpperCase['0_1_64_1_0_2']='1';

inputy.push('0_1_64_1_0_3');
inputyMena['0_1_64_1_0_3']='tf_r01_s07';
inputyId['tf_r01_s07']='0_1_64_1_0_3';
inputyTypy['0_1_64_1_0_3']='cislo';
inputyUpperCase['0_1_64_1_0_3']='1';

inputy.push('0_1_64_1_1_1');
inputyMena['0_1_64_1_1_1']='tf_r02_s05';
inputyId['tf_r02_s05']='0_1_64_1_1_1';
inputyTypy['0_1_64_1_1_1']='cislo';
inputyUpperCase['0_1_64_1_1_1']='1';

inputy.push('0_1_64_1_1_2');
inputyMena['0_1_64_1_1_2']='tf_r02_s06';
inputyId['tf_r02_s06']='0_1_64_1_1_2';
inputyTypy['0_1_64_1_1_2']='cislo';
inputyUpperCase['0_1_64_1_1_2']='1';

inputy.push('0_1_64_1_1_3');
inputyMena['0_1_64_1_1_3']='tf_r02_s07';
inputyId['tf_r02_s07']='0_1_64_1_1_3';
inputyTypy['0_1_64_1_1_3']='cislo';
inputyUpperCase['0_1_64_1_1_3']='1';

inputy.push('0_1_64_1_2_1');
inputyMena['0_1_64_1_2_1']='tf_r03_s05';
inputyId['tf_r03_s05']='0_1_64_1_2_1';
inputyTypy['0_1_64_1_2_1']='cislo';
inputyUpperCase['0_1_64_1_2_1']='1';

inputy.push('0_1_64_1_2_2');
inputyMena['0_1_64_1_2_2']='tf_r03_s06';
inputyId['tf_r03_s06']='0_1_64_1_2_2';
inputyTypy['0_1_64_1_2_2']='cislo';
inputyUpperCase['0_1_64_1_2_2']='1';

inputy.push('0_1_64_1_2_3');
inputyMena['0_1_64_1_2_3']='tf_r03_s07';
inputyId['tf_r03_s07']='0_1_64_1_2_3';
inputyTypy['0_1_64_1_2_3']='cislo';
inputyUpperCase['0_1_64_1_2_3']='1';

inputy.push('0_1_64_1_3_1');
inputyMena['0_1_64_1_3_1']='tf_r04_s05';
inputyId['tf_r04_s05']='0_1_64_1_3_1';
inputyTypy['0_1_64_1_3_1']='cislo';
inputyUpperCase['0_1_64_1_3_1']='1';

inputy.push('0_1_64_1_3_2');
inputyMena['0_1_64_1_3_2']='tf_r04_s06';
inputyId['tf_r04_s06']='0_1_64_1_3_2';
inputyTypy['0_1_64_1_3_2']='cislo';
inputyUpperCase['0_1_64_1_3_2']='1';

inputy.push('0_1_64_1_3_3');
inputyMena['0_1_64_1_3_3']='tf_r04_s07';
inputyId['tf_r04_s07']='0_1_64_1_3_3';
inputyTypy['0_1_64_1_3_3']='cislo';
inputyUpperCase['0_1_64_1_3_3']='1';

inputy.push('0_1_64_1_4_1');
inputyMena['0_1_64_1_4_1']='tf_r05_s05';
inputyId['tf_r05_s05']='0_1_64_1_4_1';
inputyTypy['0_1_64_1_4_1']='cislo';
inputyUpperCase['0_1_64_1_4_1']='1';

inputy.push('0_1_64_1_4_2');
inputyMena['0_1_64_1_4_2']='tf_r05_s06';
inputyId['tf_r05_s06']='0_1_64_1_4_2';
inputyTypy['0_1_64_1_4_2']='cislo';
inputyUpperCase['0_1_64_1_4_2']='1';

inputy.push('0_1_64_1_4_3');
inputyMena['0_1_64_1_4_3']='tf_r05_s07';
inputyId['tf_r05_s07']='0_1_64_1_4_3';
inputyTypy['0_1_64_1_4_3']='cislo';
inputyUpperCase['0_1_64_1_4_3']='1';

inputy.push('0_1_64_1_5_1');
inputyMena['0_1_64_1_5_1']='tf_r06_s05';
inputyId['tf_r06_s05']='0_1_64_1_5_1';
inputyTypy['0_1_64_1_5_1']='cislo';
inputyUpperCase['0_1_64_1_5_1']='1';

inputy.push('0_1_64_1_5_2');
inputyMena['0_1_64_1_5_2']='tf_r06_s06';
inputyId['tf_r06_s06']='0_1_64_1_5_2';
inputyTypy['0_1_64_1_5_2']='cislo';
inputyUpperCase['0_1_64_1_5_2']='1';

inputy.push('0_1_64_1_5_3');
inputyMena['0_1_64_1_5_3']='tf_r06_s07';
inputyId['tf_r06_s07']='0_1_64_1_5_3';
inputyTypy['0_1_64_1_5_3']='cislo';
inputyUpperCase['0_1_64_1_5_3']='1';

inputy.push('0_1_64_1_6_1');
inputyMena['0_1_64_1_6_1']='tf_r07_s05';
inputyId['tf_r07_s05']='0_1_64_1_6_1';
inputyTypy['0_1_64_1_6_1']='cislo';
inputyUpperCase['0_1_64_1_6_1']='1';

inputy.push('0_1_64_1_6_2');
inputyMena['0_1_64_1_6_2']='tf_r07_s06';
inputyId['tf_r07_s06']='0_1_64_1_6_2';
inputyTypy['0_1_64_1_6_2']='cislo';
inputyUpperCase['0_1_64_1_6_2']='1';

inputy.push('0_1_64_1_6_3');
inputyMena['0_1_64_1_6_3']='tf_r07_s07';
inputyId['tf_r07_s07']='0_1_64_1_6_3';
inputyTypy['0_1_64_1_6_3']='cislo';
inputyUpperCase['0_1_64_1_6_3']='1';

inputy.push('0_1_64_1_7_1');
inputyMena['0_1_64_1_7_1']='tf_r08_s05';
inputyId['tf_r08_s05']='0_1_64_1_7_1';
inputyTypy['0_1_64_1_7_1']='cislo';
inputyUpperCase['0_1_64_1_7_1']='1';

inputy.push('0_1_64_1_7_2');
inputyMena['0_1_64_1_7_2']='tf_r08_s06';
inputyId['tf_r08_s06']='0_1_64_1_7_2';
inputyTypy['0_1_64_1_7_2']='cislo';
inputyUpperCase['0_1_64_1_7_2']='1';

inputy.push('0_1_64_1_7_3');
inputyMena['0_1_64_1_7_3']='tf_r08_s07';
inputyId['tf_r08_s07']='0_1_64_1_7_3';
inputyTypy['0_1_64_1_7_3']='cislo';
inputyUpperCase['0_1_64_1_7_3']='1';

inputy.push('0_1_64_2_0_1');
inputyMena['0_1_64_2_0_1']='tf_r01_s08';
inputyId['tf_r01_s08']='0_1_64_2_0_1';
inputyTypy['0_1_64_2_0_1']='cislo';
inputyUpperCase['0_1_64_2_0_1']='1';

inputy.push('0_1_64_2_0_2');
inputyMena['0_1_64_2_0_2']='tf_r01_s09';
inputyId['tf_r01_s09']='0_1_64_2_0_2';
inputyTypy['0_1_64_2_0_2']='cislo';
inputyUpperCase['0_1_64_2_0_2']='1';

inputy.push('0_1_64_2_0_3');
inputyMena['0_1_64_2_0_3']='tf_r01_s10';
inputyId['tf_r01_s10']='0_1_64_2_0_3';
inputyTypy['0_1_64_2_0_3']='cislo';
inputyUpperCase['0_1_64_2_0_3']='1';

inputy.push('0_1_64_2_1_1');
inputyMena['0_1_64_2_1_1']='tf_r02_s08';
inputyId['tf_r02_s08']='0_1_64_2_1_1';
inputyTypy['0_1_64_2_1_1']='cislo';
inputyUpperCase['0_1_64_2_1_1']='1';

inputy.push('0_1_64_2_1_2');
inputyMena['0_1_64_2_1_2']='tf_r02_s09';
inputyId['tf_r02_s09']='0_1_64_2_1_2';
inputyTypy['0_1_64_2_1_2']='cislo';
inputyUpperCase['0_1_64_2_1_2']='1';

inputy.push('0_1_64_2_1_3');
inputyMena['0_1_64_2_1_3']='tf_r02_s10';
inputyId['tf_r02_s10']='0_1_64_2_1_3';
inputyTypy['0_1_64_2_1_3']='cislo';
inputyUpperCase['0_1_64_2_1_3']='1';

inputy.push('0_1_64_2_2_1');
inputyMena['0_1_64_2_2_1']='tf_r03_s08';
inputyId['tf_r03_s08']='0_1_64_2_2_1';
inputyTypy['0_1_64_2_2_1']='cislo';
inputyUpperCase['0_1_64_2_2_1']='1';

inputy.push('0_1_64_2_2_2');
inputyMena['0_1_64_2_2_2']='tf_r03_s09';
inputyId['tf_r03_s09']='0_1_64_2_2_2';
inputyTypy['0_1_64_2_2_2']='cislo';
inputyUpperCase['0_1_64_2_2_2']='1';

inputy.push('0_1_64_2_2_3');
inputyMena['0_1_64_2_2_3']='tf_r03_s10';
inputyId['tf_r03_s10']='0_1_64_2_2_3';
inputyTypy['0_1_64_2_2_3']='cislo';
inputyUpperCase['0_1_64_2_2_3']='1';

inputy.push('0_1_64_2_3_1');
inputyMena['0_1_64_2_3_1']='tf_r04_s08';
inputyId['tf_r04_s08']='0_1_64_2_3_1';
inputyTypy['0_1_64_2_3_1']='cislo';
inputyUpperCase['0_1_64_2_3_1']='1';

inputy.push('0_1_64_2_3_2');
inputyMena['0_1_64_2_3_2']='tf_r04_s09';
inputyId['tf_r04_s09']='0_1_64_2_3_2';
inputyTypy['0_1_64_2_3_2']='cislo';
inputyUpperCase['0_1_64_2_3_2']='1';

inputy.push('0_1_64_2_3_3');
inputyMena['0_1_64_2_3_3']='tf_r04_s10';
inputyId['tf_r04_s10']='0_1_64_2_3_3';
inputyTypy['0_1_64_2_3_3']='cislo';
inputyUpperCase['0_1_64_2_3_3']='1';

inputy.push('0_1_64_2_4_1');
inputyMena['0_1_64_2_4_1']='tf_r05_s08';
inputyId['tf_r05_s08']='0_1_64_2_4_1';
inputyTypy['0_1_64_2_4_1']='cislo';
inputyUpperCase['0_1_64_2_4_1']='1';

inputy.push('0_1_64_2_4_2');
inputyMena['0_1_64_2_4_2']='tf_r05_s09';
inputyId['tf_r05_s09']='0_1_64_2_4_2';
inputyTypy['0_1_64_2_4_2']='cislo';
inputyUpperCase['0_1_64_2_4_2']='1';

inputy.push('0_1_64_2_4_3');
inputyMena['0_1_64_2_4_3']='tf_r05_s10';
inputyId['tf_r05_s10']='0_1_64_2_4_3';
inputyTypy['0_1_64_2_4_3']='cislo';
inputyUpperCase['0_1_64_2_4_3']='1';

inputy.push('0_1_64_2_5_1');
inputyMena['0_1_64_2_5_1']='tf_r06_s08';
inputyId['tf_r06_s08']='0_1_64_2_5_1';
inputyTypy['0_1_64_2_5_1']='cislo';
inputyUpperCase['0_1_64_2_5_1']='1';

inputy.push('0_1_64_2_5_2');
inputyMena['0_1_64_2_5_2']='tf_r06_s09';
inputyId['tf_r06_s09']='0_1_64_2_5_2';
inputyTypy['0_1_64_2_5_2']='cislo';
inputyUpperCase['0_1_64_2_5_2']='1';

inputy.push('0_1_64_2_5_3');
inputyMena['0_1_64_2_5_3']='tf_r06_s10';
inputyId['tf_r06_s10']='0_1_64_2_5_3';
inputyTypy['0_1_64_2_5_3']='cislo';
inputyUpperCase['0_1_64_2_5_3']='1';

inputy.push('0_1_64_2_6_1');
inputyMena['0_1_64_2_6_1']='tf_r07_s08';
inputyId['tf_r07_s08']='0_1_64_2_6_1';
inputyTypy['0_1_64_2_6_1']='cislo';
inputyUpperCase['0_1_64_2_6_1']='1';

inputy.push('0_1_64_2_6_2');
inputyMena['0_1_64_2_6_2']='tf_r07_s09';
inputyId['tf_r07_s09']='0_1_64_2_6_2';
inputyTypy['0_1_64_2_6_2']='cislo';
inputyUpperCase['0_1_64_2_6_2']='1';

inputy.push('0_1_64_2_6_3');
inputyMena['0_1_64_2_6_3']='tf_r07_s10';
inputyId['tf_r07_s10']='0_1_64_2_6_3';
inputyTypy['0_1_64_2_6_3']='cislo';
inputyUpperCase['0_1_64_2_6_3']='1';

inputy.push('0_1_64_2_7_1');
inputyMena['0_1_64_2_7_1']='tf_r08_s08';
inputyId['tf_r08_s08']='0_1_64_2_7_1';
inputyTypy['0_1_64_2_7_1']='cislo';
inputyUpperCase['0_1_64_2_7_1']='1';

inputy.push('0_1_64_2_7_2');
inputyMena['0_1_64_2_7_2']='tf_r08_s09';
inputyId['tf_r08_s09']='0_1_64_2_7_2';
inputyTypy['0_1_64_2_7_2']='cislo';
inputyUpperCase['0_1_64_2_7_2']='1';

inputy.push('0_1_64_2_7_3');
inputyMena['0_1_64_2_7_3']='tf_r08_s10';
inputyId['tf_r08_s10']='0_1_64_2_7_3';
inputyTypy['0_1_64_2_7_3']='cislo';
inputyUpperCase['0_1_64_2_7_3']='1';

inputy.push('0_1_65_0');
inputyMena['0_1_65_0']='tg_r01';
inputyId['tg_r01']='0_1_65_0';
inputyTypy['0_1_65_0']='cislo';
inputyUpperCase['0_1_65_0']='1';

inputy.push('0_1_65_1');
inputyMena['0_1_65_1']='tg_r02';
inputyId['tg_r02']='0_1_65_1';
inputyTypy['0_1_65_1']='cislo';
inputyUpperCase['0_1_65_1']='1';

inputy.push('0_1_66_0');
inputyMena['0_1_66_0']='th_r01';
inputyId['th_r01']='0_1_66_0';
inputyTypy['0_1_66_0']='cislo';
inputyUpperCase['0_1_66_0']='1';

inputy.push('0_1_66_1');
inputyMena['0_1_66_1']='th_r02';
inputyId['th_r02']='0_1_66_1';
inputyTypy['0_1_66_1']='cislo';
inputyUpperCase['0_1_66_1']='1';

inputy.push('0_1_66_2');
inputyMena['0_1_66_2']='th_r03';
inputyId['th_r03']='0_1_66_2';
inputyTypy['0_1_66_2']='cislo';
inputyUpperCase['0_1_66_2']='1';

inputy.push('0_1_66_3');
inputyMena['0_1_66_3']='th_r04';
inputyId['th_r04']='0_1_66_3';
inputyTypy['0_1_66_3']='cislo';
inputyUpperCase['0_1_66_3']='1';

inputy.push('print'); 
inputyMena['print']='print'; 
inputyId['print']='print'; 
inputyTypy['print']='cislo'; 
inputyUpperCase['print']='1';
