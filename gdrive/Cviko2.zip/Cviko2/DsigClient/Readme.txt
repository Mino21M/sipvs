https://www.slovensko.sk/sk/na-stiahnutie


pre integratorov:
https://www.slovensko.sk/sk/na-stiahnutie/informacie-pre-integratorov-ap

D.Bridge JS, v1.x:
- podpora volania KEP z web stranok
- pozriet API s odvolavkou nizsie na konkretne API


Dokumentácia pre integrátorov klientskych aplikácií pre KEP balíka D.Suite/eIDAS:
- pozriet API aj s parametrami

